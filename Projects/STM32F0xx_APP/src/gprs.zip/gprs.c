#include "main.h"
#include <stdio.h>
#include <stdbool.h>
#include "gprs.h"

#ifdef __GNUC__
/* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */

usart_data_t usart_recv_data;
struct ringbuf usart_recv_ringbuf;
usart_data_t usart_send_data;
struct ringbuf usart_send_ringbuf;

void GPRS_PWRKEY_Init (void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(GPRS_PWRKEY_RCC, ENABLE);
    
    GPIO_InitStructure.GPIO_Pin = GPRS_PWRKEY_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPRS_PWRKEY_PORT, &GPIO_InitStructure);
}

//PWRKEY ���ſ���
//��Ƭ������ߵ�ƽ����PWRKEY���ţ�PWRKEY���ŵ͵�ƽ��Ч
//�� PWRKEY ��Ϊ�͵�ƽ����STATUS ��������� ��ƽ֮�󣬱�ʾ�����ɹ��� PWRKEY ���ſ����ͷţ�ͨ�����STATUS ���ŵĵ�ƽ���б�ģ���Ƿ񿪻���
// >1s��Ч
void GPRS_PWRKEY_On (void)
{
    GPIO_SetBits(GPRS_PWRKEY_PORT, GPRS_PWRKEY_PIN);
    wait(2);
    GPIO_ResetBits(GPRS_PWRKEY_PORT, GPRS_PWRKEY_PIN);
}

//�����ػ������� PWRKEY ���Źػ�
//�ػ�ģʽ������STATUS �ܽ���ָʾ�� �͵�ƽָʾģ���ѽ���ػ�ģʽ��
//�ػ������У�ģ����Ҫע�� GSM ���磬ע��ʱ���뵱ǰ����״̬�йأ����ⶨ
//��ʱԼ 2s~12s����˽����ӳ� 12s ���ٶ�ģ����жϵ�������Ĳ�������ȷ������
//ȫ�ػ�֮ǰ�������������Ҫ���ݡ�
void GPRS_PWRKEY_Off (void)
{
    GPIO_SetBits(GPRS_PWRKEY_PORT, GPRS_PWRKEY_PIN);
    wait(12);
    GPIO_ResetBits(GPRS_PWRKEY_PORT, GPRS_PWRKEY_PIN);
}

uint8_t GPRS_STATUS_Read (void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_AHBPeriphClockCmd(GPRS_STATUS_RCC, ENABLE);
    
    GPIO_InitStructure.GPIO_Pin   = GPRS_STATUS_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPRS_STATUS_PORT, &GPIO_InitStructure);
    return GPIO_ReadInputDataBit(GPRS_STATUS_PORT, GPRS_STATUS_PIN);
}

void GPRS_Config(void)
{
    ringbuf_init(&usart_recv_ringbuf, usart_recv_data.buf, 128);
    ringbuf_init(&usart_send_ringbuf, usart_send_data.buf, 128);
    GPRS_PWRKEY_Init();
    GPRS_PWRKEY_On();
    wait(2);
}

/**
* @brief Configure the USART Device
* @param  None
* @retval None
*/
void USART_Config(void)
{
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    
    /* Enable the USART Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EVAL_COM1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    /* USARTx configured as follow:
    - BaudRate = 115200 baud  
    - Word Length = 8 Bits
    - Stop Bit = 1 Stop Bit
    - Parity = No Parity
    - Hardware flow control disabled (RTS and CTS signals)
    - Receive and transmit enabled
    */
    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    
    STM_EVAL_COMInit(COM1, &USART_InitStructure);
    
    //�ڴ��ڳ�ʼ������ʱ����ORE����ж�
    //ֻҪ�����жϴ򿪣���RXNEIE����Ϊ1����ôORE�ж�Ҳ�Զ�����,ֻ�е�USART_IT_ERR�ж�ʹ��ʱ�����ܶ���ORE�ж�
    USART_ClearFlag(EVAL_COM1, USART_FLAG_RXNE);        //��ֹ������ͽ����ж�
    USART_ITConfig(EVAL_COM1, USART_IT_TXE, ENABLE);
    USART_ITConfig(EVAL_COM1, USART_IT_RXNE, ENABLE);   //�������ڽ����ж�
    USART_ITConfig(EVAL_COM1, USART_IT_ORE, ENABLE);    //������������ж�
}

/**
* @brief  Retargets the C library printf function to the USART.
* @param  None
* @retval None
*/
PUTCHAR_PROTOTYPE
{
    /* Place your implementation of fputc here */
    /* e.g. write a character to the USART */
    USART_SendData(EVAL_COM1, (uint8_t) ch);
    
    /* Loop until transmit data register is empty */
    while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TXE) == RESET)
    {}
    
    return ch;
}

void  Serial_SendByte (uint8_t ch)
{
  USART_SendData(USART1, (uint8_t) ch);
  /* Loop until the end of transmission */
  while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET)
  {}
}

void  Serial_SendBytes (const uint8_t *const buf, uint32_t len)
{
    uint8_t *_buf = (uint8_t *)buf;
    while (len--)
        Serial_SendByte(*(_buf++));
}

char readByte(void)
{
    return ringbuf_get(&usart_recv_ringbuf);
}

bool readable(void)
{
    if(ringbuf_elements(&usart_recv_ringbuf) > 0 )
        return true;
    else
        return false;
}

int readBuffer(char *buffer, int count, unsigned int timeout)
{
    int i = 0;
    unsigned int _timeout = 0;
    while(1) {
        while ( readable() ) {
            char c = readByte();
            _timeout = 0;
            if (c == '\r' || c == '\n') c = '$';
            buffer[i++] = c;
            if(i >= count)break;//����while ( readable() )
        }
        if(i >= count)break;//����while(1)
        _timeout++;
        wait_ms(1);
        if(_timeout >= timeout)break;
    }
    wait(0.5);
    while (readable())
        readByte();
    return 0;
}

void cleanBuffer(char *buffer, int count)
{
    for(int i=0; i < count; i++) {
        buffer[i] = '\0';
    }
}

void sendCmd(const char* const cmd)
{
    int i = 0;
    while (*(cmd+i) != '\0')
    {
        ringbuf_put(&usart_send_ringbuf, *(cmd+i));
        USART_ITConfig(EVAL_COM1, USART_IT_TXE, ENABLE);
        i++;
    }
}

int waitForResp(const char *resp, unsigned int timeout)
{
    int len = strlen(resp);
    int sum=0;
    unsigned int _timeout = 0;

    while(1) {
        if(readable()) {
            signed char c;
            _timeout = 0;
            c = readByte();
            sum = (c==resp[sum]) ? sum+1 : 0;
            if(sum == len)break;
        }
        wait_ms(1);
        if (_timeout++ >= timeout) return false;
    }
    //wait_ms(1);
    while (readable())
        (void)readByte();
    return true;
}

int sendCmdAndWaitForResp(const char* const data, const char * const resp, unsigned timeout)
{
    sendCmd(data);
    return waitForResp(resp,timeout);
}

int powerCheck(void)
{
    return sendCmdAndWaitForResp("AT\r\n", "OK", 2000);
}

int checkSIMStatus(void)
{
    char gprsBuffer[30];
    int count = 0;
    cleanBuffer(gprsBuffer,30);
    while(count < 3) {
        sendCmd("AT+CPIN?\r\n");
        readBuffer(gprsBuffer,30,1000);
        if((NULL != strstr(gprsBuffer,"+CPIN: READY"))) {
            break;
        }
        count++;
        wait(1);
    }
 
    if(count == 3) {
        return -1;
    }
    return 0;
}

int checkSignalStrength(void)
{
    char gprsBuffer[100];
    int index,count = 0;
    cleanBuffer(gprsBuffer,100);
    while(count < 3) {
        sendCmd("AT+CSQ\r\n");
        readBuffer(gprsBuffer,25,1000);
        if(sscanf(gprsBuffer, "AT+CSQ$$$$+CSQ: %d", &index)>0) {
            break;
        }
        count++;
        wait(1);
    }
    if(count == 3) {
        return -1;
    }
    return index;
}

int networkInit(char* apn, char* userName, char* passWord)
{
    char cstt[64];
    snprintf(cstt,sizeof(cstt),"AT+CSTT=\"%s\",\"%s\",\"%s\"\r\n",apn,userName,passWord);
    if(0 != sendCmdAndWaitForResp(cstt, "OK", 5000)) {
        return -1;
    }
    return 0;
}
 
bool connectTCP(char *ip, char *port)
{
    char cipstart[64];
#if 0
    if(0 != sendCmdAndWaitForResp("AT+CSTT=\"CMNET\",\"\",\"\"\r\n", "OK", 5)) {
        return -1;
    }
#endif
    sprintf(cipstart, "AT+CIPSTART=\"TCP\",\"%s\",\"%s\"\r\n", ip, port);
    if(0 != sendCmdAndWaitForResp(cipstart, "CONNECT", 5000)) {
        return false;
    }
    return true;
}

int sendTCPData(char *data)
{
    char cmd[64];
    int len = strlen(data);
    snprintf(cmd,sizeof(cmd),"AT+CIPSEND=%d\r\n",len);
    if(0 != sendCmdAndWaitForResp(cmd,">",5000)) {
        return -1;
    }
    if(0 != sendCmdAndWaitForResp(data,"OK",5000)) {
        return -1;
    }
    return 0;
}

int closeTCP(void)
{
    sendCmd("AT+CIPCLOSE\r\n");
    return 0;
}

int shutTCP(void)
{
    sendCmd("AT+CIPSHUT\r\n");
    return 0;
}

void sendATTest(void)
{
netInit:
    int ret;
    int timeout = 0;
    while ((ret = sendCmdAndWaitForResp("AT\r\n","OK",1000)) != true)
    {
//        if (timeout++ > 3)
//            break;
    }
//    if (timeout > 3)
//    {
//        printf("GPRS_PWRKEY_On:%d\r\n", timeout);
//        GPRS_PWRKEY_On();
//        goto netInit;
//    }
    
//    //��ѯ SIM ����״̬����Ҫ�� PIN ��
//    while ((ret = sendCmdAndWaitForResp("AT+CPIN?\r\n","OK",2000)) != true)
//        printf("ret = %d\r\n", ret);
    
//    //��������ź�ǿ��
//    while ((ret = sendCmdAndWaitForResp("AT+CSQ\r\n","OK",2000)) != true)
//        printf("ret = %d\r\n", ret);
    
//    //��ѯ��ǰ��Ӫ�̣���ָ��ֻ������������󣬲ŷ�����Ӫ�̣����򷵻ؿ�
//    while ((ret = sendCmdAndWaitForResp("AT+COPS?\r\n","OK",2000)) != true)
//        printf("ret = %d\r\n", ret);
    
//    //��ѯģ���ͺţ��緵�أ� SIMCOM_SIM800C
//    while ((ret = sendCmdAndWaitForResp("AT+CGMM\r\n","OK",1000)) != true)
//        printf("ret = %d\r\n", ret);
    
//    //��ѯ�������룬������ SIM ����λ��ʱ��ſ��Բ�ѯ
//    while ((ret = sendCmdAndWaitForResp("AT+CNUM\r\n","OK",1000)) != true)
//        printf("ret = %d\r\n", ret);
    
    //���ø��źͷ��� GPRS ҵ��
    while ((ret = sendCmdAndWaitForResp("AT+CGATT=1\r\n","OK",1000)) != true)
        printf("ret = %d\r\n", ret);
    
    while ((ret = sendCmdAndWaitForResp("AT+CIPMODE=1\r\n","OK",1000)) != true)
        printf("ret = %d\r\n", ret);
    
    //��ʼ��������APN
    while ((ret = sendCmdAndWaitForResp("AT+CSTT=\"CMNET\"\r\n","OK",1000)) != true)
        printf("ret = %d\r\n", ret);
    
    //����������·
    while ((ret = sendCmdAndWaitForResp("AT+CIICR\r\n","OK",1000)) != true)
        printf("ret = %d\r\n", ret);
    
    //��ñ���IP��ַ
    while ((ret = sendCmdAndWaitForResp("AT+CIFSR\r\n",".",1000)) != true)
        printf("ret = %d\r\n", ret);
    
    while ((ret = connectTCP("122.114.122.174", "46880")) != true)
        printf("ret = %d\r\n", ret);
}


void sendNTPTest(void)
{
    int ret = sendCmdAndWaitForResp("AT\r\n","OK",1000);
    printf("ret = %d\r\n", ret);
    
}


void prvGprsTask( void *pvParameters )
{
    GPRS_Config();
    /* USART configuration */
    USART_Config();
    
	for( ;; )
	{
        
    }
}